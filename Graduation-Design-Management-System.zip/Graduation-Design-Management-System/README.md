# 高校毕业设计管理系统

#### 介绍
本人大学毕业设计题目
使用eclipse Oxygen开发

#### 安装教程

1. 新建数据库 "graduation-design-management"
2. 运行 "DB.sql" 文件
3. 运行项目

#### 使用说明

1. JDK1.8
2. MYSQL 5.5
3. Tomcat 8.5

#### 参与贡献

1. Fork 本仓库
2. 新建 Feat_xxx 分支
3. 提交代码
4. 新建 Pull Request


